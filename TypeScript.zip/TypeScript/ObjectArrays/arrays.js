var courses = ['Angular', 'React js', 'ES6', 'JMS']; // if we use any type we can add or use anything on array like datatype
courses.push("Spring Security"); // push method is used to add elements in array
courses.push(89);
for (var i = 0; i < courses.length; i++) {
    console.log(courses[i]);
}
// De Structing Arrays
var x = courses[0];
var y = courses[1];
var a = courses[0], b = courses[1], c = courses[2];
console.log(a);
console.log(b);
console.log(c);
