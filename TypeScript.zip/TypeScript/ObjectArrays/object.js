var student = {
    firstName: "Pooja",
    lastName: "Kolipakula",
    score: 90
}; //object 
console.log(student.firstName);
console.log(student.score);
// for in loop 
for (var item in student) {
    console.log(item);
    console.log(student[item]); //it returns value
}
//Destructing Arrays
var firstName = student.firstName, lastName = student.lastName;
console.log(firstName + " " + lastName);
