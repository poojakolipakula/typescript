var levels:number[]= [20,30,40,566,687]

console.log(levels.toString())
console.log(levels.join(" "))
console.log(levels.slice(3,4))
levels.splice(2,3,44,36)
console.log(levels.toString())
levels.push(10,20,30);
console.log(levels.toString())
console.log(levels.pop())