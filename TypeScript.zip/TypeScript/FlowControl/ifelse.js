var x = 10;
var y = 20;
if (x > y) {
    console.log("X is greater");
}
else {
    console.log("Y is greater");
}
