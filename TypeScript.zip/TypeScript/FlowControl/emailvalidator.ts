var email:string="test@test.com"
var atposition:number = email.indexOf('@');
var dotposition:number = email.indexOf('.');

if(atposition ==-1 || dotposition ==-1){
    console.log(`invalid email ${email}`)
}
else{
    console.log(`Valid Email`)
}