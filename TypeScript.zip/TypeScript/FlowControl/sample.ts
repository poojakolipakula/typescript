var n:number= 20 ;

// var n:number =prompt("Enter a number :")

var i=1;
for (i =1;i<=n;i++){
while(i%5!=0)

{

    console.log(i);

    i++;

}
}