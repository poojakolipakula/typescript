var x:number =3;

switch(x){
    case 1:
        console.log("Case 1")
        break;
    case 2:
        console.log("case 2")
        break;
    case 3:
        console.log("Case 3")
        break;
    default:
        console.log("Default")
}