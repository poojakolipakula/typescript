const pi=3.14
//we cant chnage the value once ud efine const
//pi=3.4;

const product=function(x:number,y:number):number{
    return x+y;
}

/*product =function(x:number,y:number):number{
    return x*y;
}*/

//To overcome override problems we can use const.