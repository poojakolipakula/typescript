var hello =(name:string):string=>{
    return "Hello "+ name;
}; //To use this function we have to assign to a variable

var multiplyv=(n1:number,n2:number):number=>
{
    return n1*n2;
}

//ARRAYS

var myarray:Array<any> = [];

for(var i=0;i<10;i++)
{
    myarray.push(():number=>{return i})
}

for(var i=0;i<10;i++)
{
    console.log(myarray[i]());
}

//console.log(hello("pooja"));
//passing parameter
console.log(multiplyv(8,0))