//by using doubleme in ts it restricts overload and we can use any keyword.

// if we use let keyword we cant chnage the value . 
// if we use var w ecan chnage the value

function doubleMe(x:number);
function doubleMe(x:string)

function doubleMe(x:any){
    if(x && typeof x==="number")
    {
        console.log(x*2)
    }
    else if(x&& typeof x==="string")
    {
        console.log(x+" "+x);
    }
}

doubleMe(4);
doubleMe("john")