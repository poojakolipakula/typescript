var hello=function (name:string): string{
    return "Hello "+name;//Anonymous type/func

}
function add(n1:number,n2:number):number{
    return n1+n2;
}
function display(id:number,name:string,role?:string){
    console.log("Id",id);
    console.log("name",name)
    if(role!=undefined){
    console.log("Role",role)
    }
}
// function calculator(fun:any):void{
//     console.log(fun(10,20));
// }

function calculator():any{
    function subtract(num1:number,num2:number) :number {
        return num1-num2;
    }
    return subtract;
}
// console.log(hello("Pooja"));
// console.log("Sum is "+add(10,20));
// display(1,"Pooja")
// calculator(add);

var sub =calculator();
console.log(sub(10,5));
console.log(calculator()(20,5))