var product = function(...nums)//vardias
//var product = function(x:number,y:number,...nums:number[]) // rest params
{//we can give nay number of inputs . nums is internally data structure
    var result = 1;

    for(var i=0;i<nums.length;i++){
        console.log(nums[i]);
        result *=nums[i]
    }
    return result;
}
console.log(product(2,3,4,5,6))