
var average=0
var maths :number=parseInt(prompt("Enter maths marks :"))
var physics:number=parseInt(prompt("Enter physics marks :" ))
var Chemistry:number=parseInt(prompt("Enter chemistry marks :"))

var average=(maths+physics+Chemistry)/3

if(average<70)
{
    console.log("C Grade")
} else if(average>70 && average<90){
    console.log("B grade")
}
else{
    console.log("A Grade")
}