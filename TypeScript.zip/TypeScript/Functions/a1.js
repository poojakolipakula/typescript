var prime = function (n) {
    var i = 0;
    for (i = 0; i <= n; i++) {
        if (n % 2 == 0) {
            console.log("not prime");
        }
        else if (n == 1) {
            console.log("1 is neither prime or odd ");
        }
        else {
            console.log("prime");
        }
    }
};
var a = parseInt(prompt("Enter a number "));
prime(a);
