function hello(name) {
    return "Hello " + name;
}
function add(n1, n2) {
    return n1 + n2;
}
function display(id, name, role) {
    console.log("Id", id);
    console.log("name", name);
    if (role != undefined) {
        console.log("Role", role);
    }
}
// function calculator(fun:any):void{
//     console.log(fun(10,20));
// }
function calculator() {
    function subtract(num1, num2) {
        return num1 - num2;
    }
    return subtract;
}
// console.log(hello("Pooja"));
// console.log("Sum is "+add(10,20));
// display(1,"Pooja")
// calculator(add);
var sub = calculator();
console.log(sub(10, 5));
console.log(calculator()(20, 5));
