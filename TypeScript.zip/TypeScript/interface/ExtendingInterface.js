var myCar = {
    make: "Honda",
    model: "Civic",
    year: 2023,
    color: "white",
    doors: 4,
    seats: 5,
    auto: true
};
