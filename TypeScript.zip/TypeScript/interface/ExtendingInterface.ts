interface Exterior{
    doors:number;
    color:string;
}

interface Interior{
    seats:number;
    auto:boolean;
}

interface Car extends Exterior,Interior{
    make:string;
    model:string;
    year:number;
}

var myCar:Car={
    make:"Honda",
    model:"Civic",
    year:2023,
    color:"white",
    doors:4,
    seats:5,
    auto:true
}