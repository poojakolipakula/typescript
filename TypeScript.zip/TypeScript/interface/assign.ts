interface Book{
    title:string;
    isbn:string;
    description:string;
    price:number
}

var book:Book={
    title:"Harry potter",
    isbn:"About harry potter",
    description:"Such a magic",
    price:100
}