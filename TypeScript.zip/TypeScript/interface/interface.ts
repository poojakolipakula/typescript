interface Product{
    id:number;
    name:string;
    description:string;
    price?:number;//? --optional parameter
    display():void; //method implemnatation
}

var product1:Product ={
    id:123,
    name:"ANdroid",
    description:"Comfort to use",
    display():void{
        console.log(this.id+ " " +this.name)
    }
}

//optional parameters
var product2:Product ={
    id:123,
    name:"ANdroid",
    description:"Comfort to use",
    price:30000,
    display():void{
        console.log(this.id+ " " +this.name)
    }
}