interface StudentName{
    [index:number]:string;
}

var studentNames:StudentName=['John','Son','Doug']

interface StudentScores{
    [index:string]:number;
}

var studentScores:StudentScores={};

studentScores["john"]=1;
studentScores['son']=2;

for(var item in studentScores){
    console.log(item);
    console.log(studentScores);
}