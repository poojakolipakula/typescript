var studentNames = ['John', 'Son', 'Doug'];
var studentScores = {};
studentScores["john"] = 1;
studentScores['son'] = 2;
for (var item in studentScores) {
    console.log(item);
    console.log(studentScores);
}
