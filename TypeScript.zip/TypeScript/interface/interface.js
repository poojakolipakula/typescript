var product1 = {
    id: 123,
    name: "ANdroid",
    description: "Comfort to use"
};
//optional parameters
var product2 = {
    id: 123,
    name: "ANdroid",
    description: "Comfort to use",
    price: 30000
};
