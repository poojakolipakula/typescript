enum Gender {
    Male,
    Female //constants 
}

console.log(Gender.Male)
console.log(Gender.Female)
console.log(Gender[0])
console.log(Gender[1])

enum weekends{
    saturday=6,
    sunday=7
}
console.log(weekends[6])
console.log(weekends[7])
