var sn:string | number;
sn="pooja"
sn=10
