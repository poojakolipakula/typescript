var sn;
sn = "pooja";
sn = 10;
