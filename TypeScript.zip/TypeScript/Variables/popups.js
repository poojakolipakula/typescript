console.log("Hello");
alert("Hello");
confirm("U want to confirm");
var data = prompt("Please enter ur name");
console.log(data);
