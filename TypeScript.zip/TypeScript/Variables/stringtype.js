var s1 = "<a href=''/>";
var userName = "pooja";
var s2 = "My \\ name is ".concat(userName);
console.log(s2);
console.log(s2.length);
console.log(s2.charAt(0));
console.log(s2.indexOf('n'));
console.log(s2.lastIndexOf('n'));
// '\' backslash is escape sequance charater
