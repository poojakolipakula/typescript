var Gender;
(function (Gender) {
    Gender[Gender["Male"] = 0] = "Male";
    Gender[Gender["Female"] = 1] = "Female"; //contants 
})(Gender || (Gender = {}));
console.log(Gender.Male);
console.log(Gender.Female);
console.log(Gender[0]);
console.log(Gender[1]);
var weekends;
(function (weekends) {
    weekends[weekends["saturday"] = 6] = "saturday";
    weekends[weekends["sunday"] = 7] = "sunday";
})(weekends || (weekends = {}));
console.log(weekends[6]);
console.log(weekends[7]);
