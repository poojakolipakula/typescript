var n1 = 10; // in js var n1=10;
console.log(n1);
var s1 = "Pooja";
var s2 = "You are the creator of your destiny";
console.log(s1);
console.log(s2);
var s3 = s1;
console.log(s3);
var b1 = true;
var b2 = false;
console.log(b1);
console.log(b2);
var a1 = {
    productid: 1,
    productname: "iphone",
    productPrice: 1000
};
console.log(a1);
//Homogenous Array -- Homo means we can use only one datatype
var array1 = ["AngularJS", "ReactJS"];
console.log(array1);
console.log(array1[0]);
console.log(array1.length);
//Heterogeneous Array Array<any>
var array2 = [1, "pooja", "uta ayitha"];
console.log(array2);
