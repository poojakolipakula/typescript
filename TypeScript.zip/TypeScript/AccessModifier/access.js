var Student = /** @class */ (function () {
    function Student() {
    }
    Student.prototype.display = function () {
        console.log(this._name);
    };
    Object.defineProperty(Student.prototype, "getName", {
        get: function () {
            return this._name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Student.prototype, "setName", {
        set: function (name) {
            this._name = name; //set dont have return type
        },
        enumerable: false,
        configurable: true
    });
    return Student;
}());
var student = new Student();
student.setName = "John";
document.write(student.getName); //it will be easy for set and get name.
// while re=unning get set methods in ts we have to transcompile -- tsc --target es5 access.ts
