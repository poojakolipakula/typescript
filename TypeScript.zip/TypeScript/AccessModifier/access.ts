class Student{
    private _name:string;

    display(){
        console.log(this._name);
    }

    get getName():string{ //we can give any name like inplace getName =name
        return this._name;
    }

    set setName(name:string){ //similarly setName =name
        this._name=name;//set dont have return type
    }
}

var student = new Student();
student.setName="John"
console.log(student.getName) //it will be easy for set and get name.

// while re=unning get set methods in ts we have to transcompile -- tsc --target es5 access.ts