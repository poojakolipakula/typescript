class Organizer{
    private _id:number;
    private _name:string;
    get name():string{
        return this._name;
    }
    set name(name:string){
        this._name=name;
    }
}

class Events{
    private _id:number;
    private _name:string;
    private _description:string;
    private _starttime:number;
    private _endtime:number;

    get name():string{
        return this._name +" "+this._description+" "+this._starttime+" "+this._endtime;
    }
    set name(name:string,){
        this._name=name;
        
    }
    set description(description:string){
        this._description=description;
    }
    set starttime(starttime:number){
        this._starttime=starttime;
    }
    set endtime(endtime:number){
        this._endtime=endtime;
    }
}

class Venue{
    private _id:number;
    private _name:string;
    private _description:string;   
    private _address:string;

    get name():string{
        return this._name +" " +this._description+" "+this._address;
    }
    set name(name:string){
        this._name=name;
    }
    set description(description:string){
        this._description=description;
    }
    set address(address:string){
        this._address=address;
    }
}


var organizer=new Organizer()
organizer.name="Capgemini"
console.log(organizer.name)

var events= new Events()
events.name="Function"
events.description="A suspense "
events.starttime=7;
events.endtime=9;
console.log(events.name)
console.log(events.description)
console.log(events.starttime)
console.log(events.endtime)

var venue= new Venue()
venue.name="Alankar"
venue.description="A beautiful place for alll kinds functions"
venue.address="1 town "
console.log(venue.name)
console.log(venue.description)
console.log(venue.address)
