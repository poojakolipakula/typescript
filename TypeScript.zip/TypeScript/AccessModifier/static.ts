class Check{
    static bankName:string="HDFC"; //if we use statis means it comews under class
    accNo:number;
    customerName:string;
    routingNo:number;

    display(){
        Check.bankName="hdfc"
        console.log(Check.bankName)
    }

}

var check=new Check();
//Check.bankName="BOA" //without static.

//console.log(Check.bankName)

check.display();