var Organizer = /** @class */ (function () {
    function Organizer() {
    }
    Object.defineProperty(Organizer.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (name) {
            this._name = name;
        },
        enumerable: false,
        configurable: true
    });
    return Organizer;
}());
var Events = /** @class */ (function () {
    function Events() {
    }
    Object.defineProperty(Events.prototype, "name", {
        get: function () {
            return this._name + " " + this._description + " " + this._starttime + " " + this._endtime;
        },
        set: function (name) {
            this._name = name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Events.prototype, "description", {
        set: function (description) {
            this._description = description;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Events.prototype, "starttime", {
        set: function (starttime) {
            this._starttime = starttime;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Events.prototype, "endtime", {
        set: function (endtime) {
            this._endtime = endtime;
        },
        enumerable: false,
        configurable: true
    });
    return Events;
}());
var Venue = /** @class */ (function () {
    function Venue() {
    }
    Object.defineProperty(Venue.prototype, "name", {
        get: function () {
            return this._name + " " + this._description + " " + this._address;
        },
        set: function (name) {
            this._name = name;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Venue.prototype, "description", {
        set: function (description) {
            this._description = description;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Venue.prototype, "address", {
        set: function (address) {
            this._address = address;
        },
        enumerable: false,
        configurable: true
    });
    return Venue;
}());
var organizer = new Organizer();
organizer.name = "Capgemini";
// console.log(organizer.name)
var events = new Events();
events.name = "Function";
events.description = "A suspense ";
events.starttime = 7;
events.endtime = 9;
// console.log(events.name)
// console.log(events.description)
// console.log(events.starttime)
// console.log(events.endtime)
var venue = new Venue();
venue.name = "Alankar";
venue.description = "A beautiful place for alll kinds functions";
venue.address = "1 town ";
// document.write(venue.name)
// console.log(venue.description)
// console.log(venue.address)
