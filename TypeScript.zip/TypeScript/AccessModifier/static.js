var Check = /** @class */ (function () {
    function Check() {
    }
    Check.prototype.display = function () {
        Check.bankName = "hdfc";
        console.log(Check.bankName);
    };
    Check.bankName = "HDFC"; //if we use statis means it comews under class
    return Check;
}());
var check = new Check();
//Check.bankName="BOA" //without static.
//console.log(Check.bankName)
check.display();
