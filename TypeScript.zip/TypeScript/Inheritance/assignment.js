var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TouchScreenLaptop = /** @class */ (function () {
    function TouchScreenLaptop(ram, hd, processor) {
        this.ram = ram;
        this.hd = hd;
        this.processor = processor;
    }
    //display():void;
    TouchScreenLaptop.prototype.scroll = function () {
        console.log("scrolling");
    };
    TouchScreenLaptop.prototype.click = function () {
        console.log("click");
    };
    return TouchScreenLaptop;
}());
var HPLaptop = /** @class */ (function (_super) {
    __extends(HPLaptop, _super);
    function HPLaptop(ram, hd, processor, selfRecovery) {
        var _this = _super.call(this, ram, hd, processor) || this;
        _this.selfRecovery = selfRecovery;
        return _this;
    }
    HPLaptop.prototype.Self = function () {
        this.selfRecovery = true;
        console.log("Recovering");
    };
    HPLaptop.prototype.scroll = function () {
        console.log("Button scrolling");
    };
    HPLaptop.prototype.click = function () {
        console.log("Button click");
    };
    HPLaptop.prototype.display = function () {
        console.log(this.ram + ", " + this.hd + ", " + this.processor + ", " + this.selfRecovery);
    };
    return HPLaptop;
}(TouchScreenLaptop));
var DellLaptop = /** @class */ (function (_super) {
    __extends(DellLaptop, _super);
    function DellLaptop(ram, hd, processor, mobileAccess) {
        var _this = _super.call(this, ram, hd, processor) || this;
        _this.mobileAccess = mobileAccess;
        return _this;
    }
    DellLaptop.prototype.mobile = function () {
        this.mobileAccess = true;
        console.log("Accessing");
    };
    DellLaptop.prototype.scroll = function () {
        console.log(" remote scrolling");
    };
    DellLaptop.prototype.click = function () {
        console.log("remote click");
    };
    DellLaptop.prototype.display = function () {
        console.log(this.ram + ", " + this.hd + ", " + this.processor + ", " + this.mobileAccess);
    };
    return DellLaptop;
}(TouchScreenLaptop));
var hpLaptop = new HPLaptop(128, 328, "Intel", false);
/* console.log(hpLaptop.selfRecovery)
console.log(hpLaptop.ram)
console.log(hpLaptop.hd)
console.log(hpLaptop.processor) */
//HPLaptop.commonEngineFunc();
hpLaptop.scroll();
hpLaptop.click();
hpLaptop.Self();
hpLaptop.display();
var dellLaptop = new DellLaptop(256, 123, "Intel", false);
/* console.log(dellLaptop.mobileAccess)
console.log(dellLaptop.ram)
console.log(dellLaptop.hd)
console.log(dellLaptop.processor) */
//DellLaptop.commonEngineFunc();
dellLaptop.scroll();
dellLaptop.click();
dellLaptop.mobile();
dellLaptop.display();
