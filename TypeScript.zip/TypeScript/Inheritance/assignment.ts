class TouchScreenLaptop{
    ram:number;
    hd:number;
    processor:string;

    constructor(ram:number,hd:number,processor:string){
        this.ram=ram;
        this.hd=hd;
        this.processor=processor;
    }

    //display():void;

    scroll(){
        console.log("scrolling")
    }

    click(){
        console.log("click")
    } 

    
}

class HPLaptop extends TouchScreenLaptop{
    selfRecovery:boolean;

    Self(){
    this.selfRecovery=true;
        console.log("Recovering")
    }
    constructor(ram:number,hd:number,processor:string,selfRecovery:boolean){
        super(ram,hd,processor);
        this.selfRecovery=selfRecovery;
    }

    scroll(){
        console.log("Button scrolling")
    }

    click(){
        console.log("Button click")
    } 
    display(){

        console.log(this.ram + ", "+ this.hd + ", "+ this.processor + ", "+ this.selfRecovery);
    }
}

class DellLaptop extends TouchScreenLaptop{
    mobileAccess:Boolean;

    mobile(){
        this.mobileAccess=true;
        console.log("Accessing")
    }
    constructor(ram:number,hd:number,processor:string,mobileAccess:boolean){
        super(ram,hd,processor); //which will help the inherite the parent class
        this.mobileAccess=mobileAccess;
    }

    scroll(){
        console.log(" remote scrolling")
    }

    click(){
        console.log("remote click")
    }
    display(){

        console.log(this.ram + ", "+ this.hd + ", "+ this.processor + ", "+ this.mobileAccess);
    }
}

var hpLaptop =new HPLaptop(128,328,"Intel",false)
/* console.log(hpLaptop.selfRecovery)
console.log(hpLaptop.ram)
console.log(hpLaptop.hd)
console.log(hpLaptop.processor) */
//HPLaptop.commonEngineFunc();
hpLaptop.scroll();
hpLaptop.click();
hpLaptop.Self();
hpLaptop.display();

var dellLaptop =new DellLaptop(256,123,"Intel",false)
/* console.log(dellLaptop.mobileAccess)
console.log(dellLaptop.ram)
console.log(dellLaptop.hd)
console.log(dellLaptop.processor) */
//DellLaptop.commonEngineFunc();
dellLaptop.scroll();
dellLaptop.click();
dellLaptop.mobile();
dellLaptop.display();
