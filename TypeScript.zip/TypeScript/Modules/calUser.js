"use strict";
exports.__esModule = true;
var calc_1 = require(".\\calc");
var calc = new calc_1.Calculator();
console.log(calc.add(2, 3));
console.log(calc.sub(2, 3));
