// export default function add(x:number,y:number):number{
//     return x+y;
// }

// export function sub(x:number,y:number):number{
//     return x-y;
// }

//export{add,sub};

export class Calculator{
    add(x:number,y:number){
        return x+y;
    }
    sub(x:number,y:number){
        return x-y;
    }
}
