import {Calculator} from '.\\calc';
var calc=new Calculator();
console.log(calc.add(2,3))
console.log(calc.sub(2,3))

//default class we no need to use bracket
