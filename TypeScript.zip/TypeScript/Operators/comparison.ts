var x:number=10

console.log(x===10)
console.log(x!==10)
console.log(x>30)