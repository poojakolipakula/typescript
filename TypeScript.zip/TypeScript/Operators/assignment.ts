var a:number = 10
var b:number = 5

var c:number=b

c+=a
console.log(c)