var a = 10;
var b = 5;
var c = b;
c += b;
console.log(c);
