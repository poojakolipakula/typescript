console.log((10>20)&&(20>5))
console.log((10>20)||(20>5))