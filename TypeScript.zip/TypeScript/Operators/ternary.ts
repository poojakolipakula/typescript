var x:number = 20;
var y:number = 10;

console.log((x>y)?"X is greater than Y":"Y is greater than X");
