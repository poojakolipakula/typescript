var Organize = /** @class */ (function () {
    function Organize(Id, name) {
        this.Id = Id;
        this.name = name;
        //this.to=to;
    }
    Organize.prototype.display = function () {
        document.write(this.Id + " " + this.name);
    };
    return Organize;
}());
var Events = /** @class */ (function () {
    function Events(Id, name, description, starttime, endtime) {
        this.Id = Id;
        this.name = name;
        this.description = description;
        this.starttime = starttime;
        this.endtime = endtime;
    }
    Events.prototype.display = function () {
        document.write(this.Id + " " + this.name + " " + this.description + " " + this.starttime + " " + this.endtime);
    };
    return Events;
}());
var Venue = /** @class */ (function () {
    function Venue(Id, name, description, address) {
        this.Id = Id;
        this.name = name;
        this.description = description;
        this.address = this.address;
    }
    Venue.prototype.display = function () {
        document.write(this.Id + " " + this.name + " " + this.description + " " + this.address);
    };
    return Venue;
}());
var organize = new Organize(123, "Pooja");
organize.display();
var events = new Events(123, "event", "fullfunevent", 6, 9);
events.display();
var venue = new Venue(123, "event", "fullfunevent", "NEW YORK");
venue.display();
