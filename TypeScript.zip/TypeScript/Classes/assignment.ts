interface IOrganizer{
    Id:number;
    name:string;
    
    display():void;
}

class Organize implements IOrganizer{
    Id:number;
    name:string;

    constructor(Id:number,name:string){
        this.Id=Id;
        this.name=name;
        //this.to=to;
    }
    display(){
        document.write(this.Id+" "+this.name)
    }
}

interface IEvent{
    Id:number;
    name:string;
    description:string;
    starttime:number;
    endtime:number;

    display():void;
}

class Events implements IEvent{
    Id:number;
    name:string;
    description:string;
    starttime:number;
    endtime:number;

    constructor(Id:number,name:string,description:string,starttime:number,endtime:number){
        this.Id=Id;
        this.name=name;
        this.description=description;
        this.starttime=starttime;
        this.endtime=endtime;
    }
    display(){
        document.write(this.Id+" "+this.name+" "+this.description+" "+this.starttime+" "+this.endtime)
    }
}

interface IVenue{
    Id:number;
    name:string;
    description:string;
    address:string;

    display():void;
}

class Venue implements IVenue{
    Id:number;
    name:string;
    description:string;
    address:string;


    constructor(Id:number,name:string,description:string,address:string){
        this.Id=Id;
        this.name=name;
        this.description=description;
        this.address=this.address;
    }
    display(){
        document.write(this.Id+" "+this.name+" "+this.description+" "+this.address)
    }
}



var organize =new Organize(123,"Pooja");
organize.display(); 

var events =new Events(123,"event","fullfunevent",6,9);
events.display(); 

var venue =new Venue(123,"event","fullfunevent","NEW YORK");
venue.display(); 