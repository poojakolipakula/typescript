interface IFlight{
    flightNo:number;
    from:string;
    to:string;

    display():void;
}

class Flight implements IFlight{
    flightNo: number;
    from:string;
    to:string;
    flightTime:number;

    constructor(flightNo:number,from:string,to:string){
        this.flightNo=flightNo;
        this.from=from;
        this.to=to;
    }
    display(){
        document.write(this.flightNo+" "+this.from+" "+this.to)
    }
}

var flight =new Flight(123,"India","NEW YORK");
flight.display(); 