var Passenger = /** @class */ (function () {
    function Passenger(firstName, lastName, frequencyFlytno) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.frequencyFlytno = frequencyFlytno;
    }
    Passenger.prototype.display = function () {
        console.log(this.firstName + " " + this.lastName + " " + this.frequencyFlytno);
    };
    return Passenger;
}());
var passenger = new Passenger("Pooja", "kolipakula", 12345);
//console.log(passenger.firstName+" "+passenger.lastName+" "+passenger.frequencyFlytno);
passenger.display();
var passenger2 = new Passenger("Pooja", "k", 12345);
//console.log(passenger.firstName+" "+passenger.lastName+" "+passenger.frequencyFlytno);
passenger2.display();
for (var item in passenger) {
    console.log(item);
    console.log(passenger[item]);
}
