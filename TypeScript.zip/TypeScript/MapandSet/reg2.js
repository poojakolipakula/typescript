var password = "tEST1234";
var regEX = /(?=.*[A-Z])\w{4,10}/;
if (password.match(regEX)) {
    console.log('Valid');
}
else {
    console.log("not valid");
}
