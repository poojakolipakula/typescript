let expirydate:any= new Date(); //we can give Date("2025-12-23")
document.writeln(expirydate) // it will return the same date
document.writeln(expirydate.getDay())
document.writeln(expirydate.getDate())
document.writeln(expirydate.getHours())
document.writeln(expirydate.getMinutes())
document.writeln(expirydate.toTimeString())
console.log(expirydate.setDate(20));