let courses = new Set()
courses.add("ANgular crash course")
courses.add("React")
courses.add("Node")
courses.add("Serverless")
courses.add("React") //sets cant access duplicate
console.log(courses.size) //returns size
console.log(courses.values())
courses.forEach(function(course)
{
    console.log(course)
})