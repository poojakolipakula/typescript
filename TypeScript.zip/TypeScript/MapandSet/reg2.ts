let password:string="tEST1234";
let regEX:any=/(?=.*[A-Z])\w{4,10}/
if(password.match(regEX)){
    console.log('Valid')
}
else{
    console.log("not valid"+password)
}