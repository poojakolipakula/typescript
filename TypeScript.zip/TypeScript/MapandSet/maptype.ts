let studentScores = new Map([["john",90],["bob",89],["ahmed",90]])
console.log(studentScores.get("bob"))
studentScores.set("Pooja",100)
//size of map
console.log(studentScores.size)
//delete
studentScores.delete("Pooja")
//has -- true or false
console.log(studentScores.has("Pooja"))
studentScores.clear()
console.log(studentScores.has("Pooja"))
console.log(studentScores)

console.log(studentScores.keys())
//TS cant iterate directly so we are using arrays

for(let key in Array.from(studentScores.keys())){
    console.log(key)
    console.log(studentScores.get(key))
}

console.log(studentScores.values());
console.log(studentScores.entries())