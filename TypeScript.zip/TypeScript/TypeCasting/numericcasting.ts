// numeric to string 

// let x:string=prompt("Enter a number");
// let x:number=parseInt(prompt("Enter a number")) //parsefloat
// console.log(x+3);

let courses=['Angular','React','nodejs']
console.log(courses.toString())//converts into string

let mybool=false;
let x:string = mybool.toString();
console.log(x)