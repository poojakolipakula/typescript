// numeric to string 
// let x:string=prompt("Enter a number");
// let x:number=parseInt(prompt("Enter a number")) //parsefloat
// console.log(x+3);
var courses = ['Angular', 'React', 'nodejs'];
console.log(courses.toString()); //converts into string
var mybool = false;
var x = mybool.toString();
console.log(x);
