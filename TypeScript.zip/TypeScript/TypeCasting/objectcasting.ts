interface Employee{
    id:number;
}
let e1:Employee;

let e2={id:123,name:"john"}

e1=e2;
//second variable to first variable
// data of 

//we can assign e1=e2
